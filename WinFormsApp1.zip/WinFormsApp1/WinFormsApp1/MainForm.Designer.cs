﻿namespace MyExitApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnStay;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnStay = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.btnExit.Location = new System.Drawing.Point(60, 120);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 40);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Хочу вийти";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
 
            this.btnStay.Location = new System.Drawing.Point(200, 120);
            this.btnStay.Name = "btnStay";
            this.btnStay.Size = new System.Drawing.Size(160, 40);
            this.btnStay.TabIndex = 1;
            this.btnStay.Text = "Лишитися в програмі";
            this.btnStay.UseVisualStyleBackColor = true;
            this.btnStay.Click += new System.EventHandler(this.btnStay_Click);

            this.ClientSize = new System.Drawing.Size(400, 250);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnStay);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Головна форма";
            this.ResumeLayout(false);
        }
    }
}