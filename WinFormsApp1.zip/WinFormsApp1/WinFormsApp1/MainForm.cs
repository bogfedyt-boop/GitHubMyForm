﻿using System;
using System.Windows.Forms;

namespace MyExitApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Ви точно хочете вийти?",
                "Підтвердження",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                MyExitApp exitForm = new MyExitApp();
                exitForm.Show();
                this.Hide();
            }
        }

        private void btnStay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ви залишилися в програмі 😊");
        }
    }
}