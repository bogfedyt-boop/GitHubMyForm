﻿using System;
using System.Windows.Forms;

namespace MyExitApp
{
    public partial class MyExitApp : Form
    {
        public MyExitApp()
        {
            InitializeComponent();
        }
    }
}